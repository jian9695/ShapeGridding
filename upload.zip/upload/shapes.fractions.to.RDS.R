rm(list = ls())
require(sp)
require(rgdal)
require(rgeos)  # geometry ops
require(spdep)  # spatial dependence
require(foreign)  # spatial dependence
require(stringr)  # spatial dependence
require(parallel)  # spatial dependence
require(dplyr)  # spatial dependence

readFracDBF <- function(filename){
  fractionArray <- read.dbf(filename)
  if(nrow(fractionArray) == 0)
    return (fractionArray)
  bname <- basename(filename)
  idcol <- paste0('FID_',substr(bname,1,6))
  #if points without the "fraction" column, create a column named "fraction" and assign 1.0
  if("fraction" %in% colnames(fractionArray)){
  }else{
    fractionArray$fraction = 1.0
  }
  if('Id' %in% colnames(fractionArray))
  {
    colnames(fractionArray)[colnames(fractionArray)=='Id'] <- 'gridId'
  }
  
  colsOld <- c(idcol,'gridId','fraction')
  colsNew <- c('feaId','gridId','fraction') 
  if('ca10' %in% colnames(fractionArray))
  {
    colsOld <- c(idcol,'gridId','fraction','timestruct','ca10','ca11','ca12','ca13','ca14','ca15')
    colsNew <- c('feaId','gridId','fraction','timestruct','ca10','ca11','ca12','ca13','ca14','ca15')   
  }
  fractionArray <- fractionArray[,colsOld]
  # keep column names consistent
  names(fractionArray) <- colsNew
  
  return (fractionArray)
}

#change input.dir to the directory where the intersected shapefiles are located
input.dirs <- list('E:/Indy_domain_v3.2_50m/shapefile_grid_intersection_fractions/')
for (input.dir in input.dirs) {
  files <- list.files(input.dir,pattern='.dbf')
  for(name in files){
    filename <- paste0(input.dir,name)
    if(name == 'fishnet.dbf'){
      next()
    }
    print(filename)
    flush.console()
    fractionArray <- readFracDBF(filename)
    if(nrow(fractionArray) > 0)
    {
      saveRDS(fractionArray,file=paste0(input.dir,substr(name,1,nchar(name)-4),'.rds'))
    }

  }
}


